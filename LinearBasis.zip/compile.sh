#/bin/bash

g++ -std=c++11 Force.cc Main.cc Mesh.cc Solver.cc TrueSol.cc -o program

