f(x) = c
	Number of elements: 10
		Error on nodes: 		4.35718e-15
		Error on midpoints: 	0.0118585
		L2 Error: 				0.00273861
	Number of elements: 100
		Error on nodes: 		2.07453e-13
		Error on midpoints: 	0.000375
		L2 Error: 				2.73861e-05
	Number of elements: 1000
		Error on nodes: 		7.72369e-12
		Error on midpoints: 	1.18585e-05
		L2 Error: 				2.73861e-07
	Number of elements: 10000
		Error on nodes: 		1.43502e-07
		Error on midpoints: 	5.09195e-07
		L2 Error: 				4.01207e-09
f(x) = x
	Number of elements: 10
		Error on nodes: 		4.70056e-16
		Error on midpoints: 	0.00227932
		L2 Error: 				0.000526409
	Number of elements: 100
		Error on nodes: 		2.10444e-14
		Error on midpoints: 	7.21679e-05
		L2 Error: 				5.2704e-06
	Number of elements: 1000
		Error on nodes: 		7.47053e-13
		Error on midpoints: 	2.28218e-06
		L2 Error: 				5.27046e-08
	Number of elements: 10000
		Error on nodes: 		1.79264e-08
		Error on midpoints: 	8.41194e-08
		L2 Error: 				6.42655e-10
f(x) = x^2
	Number of elements: 10
		Error on nodes: 		0.00201269
		Error on midpoints: 	0.0020001
		L2 Error: 				0.00059081
	Number of elements: 100
		Error on nodes: 		6.11427e-05
		Error on midpoints: 	6.36429e-05
		L2 Error: 				5.93147e-06
	Number of elements: 1000
		Error on nodes: 		1.9254e-06
		Error on midpoints: 	2.01269e-06
		L2 Error: 				5.93171e-08
	Number of elements: 10000
		Error on nodes: 		5.13908e-08
		Error on midpoints: 	5.8532e-08
		L2 Error: 				5.24174e-10
